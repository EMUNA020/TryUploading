﻿using Microsoft.AspNetCore.Mvc;

namespace BackEndProject.Controllers
{
    public class DecisionController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
