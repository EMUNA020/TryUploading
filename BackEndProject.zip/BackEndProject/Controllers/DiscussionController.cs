﻿using Microsoft.AspNetCore.Mvc;

namespace BackEndProject.Controllers
{
    public class DiscussionController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
